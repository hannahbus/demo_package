from hbussi.sunnify import sunshine
from hbussi.beautify import main


if __name__ == '__main__':
    main() 