def sunshine(): 
    return('whatever')